# 기본문법 2단계: https://wikidocs.net/73365

# load
hr_data <- read.csv(
    "data\\HR_comma_sep.csv",
    stringsAsFactors = TRUE # char를 기본적으로 factor로 인식하도록 함. 아래 typecast로 해도 됨
)

head(hr_data, 5)
str(hr_data)
summary(hr_data)

# typecast
hr_data$Work_accident <- as.factor(hr_data$Work_accident)
hr_data$left <- as.factor(hr_data$left)
hr_data$promotion_last_5years <- as.factor(hr_data$promotion_last_5years)

summary(hr_data$left)

# add column
hr_data$satisfaction_level_group_1 <-
    ifelse(hr_data$satisfaction_level > 0.5, "High", "Low")

hr_data$satisfaction_level_group_1 <- as.factor(
    hr_data$satisfaction_level_group_1
)
str(hr_data)
summary(hr_data$satisfaction_level_group_1)

#hr_data$satisfaction_level_group_2 <-
#    ifelse(hr_data$satisfaction_level > 0.8, "High",
#    ifelse(hr_data$satisfaction_level > 0.5, "Mid", "Low"))
hr_data$satisfaction_level_group_2 <- with(hr_data,
    ifelse(satisfaction_level > 0.8, "High",
    ifelse(satisfaction_level > 0.5, "Mid", "Low"))
) # with을 이용해 위 주석 코드 줄임

hr_data$satisfaction_level_group_2 <- as.factor(
    hr_data$satisfaction_level_group_2
)
str(hr_data)
summary(hr_data$satisfaction_level_group_2)

# extract subset
hr_data_high <- subset(hr_data, salary == "high")
summary(hr_data_high)

hr_data_high_it <- subset(hr_data, salary == "high" & sales == "IT") # OR일 경우 |
summary(hr_data_high_it)
print(xtabs(~ hr_data_high_it$sales + hr_data_high_it$salary))

# create Aggregate data by plyr
#install.packages("plyr")
library(plyr)

## ddply: "d"ataframe 입력 -> "d"ataframe 출력, "ply"r 패키지
## summarise는 지정한 기준항목 기준으로 요약정보를 만듬(집계)
## ex. sum, mean, min, max, ...
hr_aggr_data <- ddply(
    hr_data, # 입력값
    c("sales", "salary"), # 입력값의 기준 항목
    summarise, # custom func OR preset
    mean_satisfaction_level = mean(satisfaction_level),
    count_items = length(sales),
    #count_salary = length(salary), # count_items와 동일
    mean_average_montly_hours = mean(average_montly_hours)
)

summary(hr_aggr_data)

# create additional columns by plyr
## transform은 각 행별로 연산을 수행해서 해당 결과를 각 열로 추가해 줌
## 추가되는 열끼리 값을 참고하는 경우 에러(ex. A열 및 B열을 새로 추가하며, A=mean(기존항목), B=log(A)인 경우)
## 위 경우 transform 대신 mutate 사용(transform 개선 함수)
hr_trans_data <- ddply(
    hr_data, # 입력값
    .(sales), # 입력값의 기준 항목
    transform, # custom func OR preset
    satisfaction_level_mean = mean(satisfaction_level), # 기준항목(sales) 별 평균값
    satisfaction_level_diff = max(satisfaction_level) - satisfaction_level
)

hr_trans_data$satisfaction_level_mean <-
    as.factor(hr_trans_data$satisfaction_level_mean)

summary(hr_trans_data)
str(hr_trans_data)

# draw graph with ggplot2 (미완)
#install.packages("ggplot2")
#install.packages("ggthemes")
library(ggplot2)
library(ggthemes)

