# 기본문법 1단계: https://wikidocs.net/73348

# vsCode에서 전체실행: Ctrl+Shift+S(또는 우측 상단 Run Source 버튼)
# vsCode에서 선택실행: Ctrl+Enter

# variable
var <- 2
print(var)
print(var == 2)
print(var != 2)

# concatenate (vector)
## 배열
var_vector <- c(9, 8, 7, 6, 5)
print(var_vector)
var_vector2 <- c(9:5) # = c(9, 8, 7, 6, 5)
print(var_vector2)
print(var_vector + var_vector2)
var_vector3 <- c(1, 2, "a") # 모두 문자열 타입으로 변환됨
print(var_vector3)

length(var_vector)

# sequence
## 규칙대로 배열 생성
var_vector_seq <- seq(from = 5, to = 9, by = 2) # = c(5, 7, 9)
print(var_vector_seq)
var_vector_seq2 <- seq(from = 10, to = 1, by = -1) # = c(10, 9, 8, ..., 2, 1)
print(var_vector_seq2)

# replicate
## 앞의 항목을 뒤의 숫자만큼 반복하여 배열 생성
var_vector_rep <- rep(7, 3) # = c(7, 7, 7)
print(var_vector_rep)
var_vector_rep2 <- rep(c(7, 8), 3) # = c(7, 8, 7, 8, 7, 8)
print(var_vector_rep2)
var_vector_rep3 <- rep(c(7, 8), c(3, 5)) # = c(7, 7, 7, 8, 8, 8, 8, 8)
print(var_vector_rep3)

# matrix
## 2차원 배열 생성
## 하나의 matric의 data는 모두 같은 타입이어야 함
var_matrix <- matrix(data = c(1:10), nrow = 5, ncol = 2, byrow = FALSE)
print(var_matrix)
var_matrix_simple <- matrix(data = c(1:10), nrow = 5) # nrow or ncol만 기입해도 자동 계산
print(var_matrix_simple)
var_matrix_simple_byrow <- matrix(data = c(1:10), nrow = 5, byrow = TRUE)
print(var_matrix_simple_byrow)

dim(var_matrix)

# dataframe
## 데이터 세트
## 각 항목은 다른 타입의 데이터여도 됨
var_dataframe <- data.frame(
    int <- c(1:3),
    ext_rep <- var_vector_rep,
    ext_seq <- var_vector_seq
)
print(var_dataframe)
print(head(var_dataframe, 2)) # 지정된 수만큼만 가져옴

print(var_dataframe$int)
print(var_dataframe$ext_rep)
print(var_dataframe$ext_seq)

var_dataframe$add_int <- c(7:9) # 추가
print(var_dataframe)

# view type(toString)
str(var)
str(var_vector)
str(var_vector_rep)
str(var_matrix)
str(var_dataframe)

# date
var_date <- as.Date("2020.12.31", format = "%Y.%m.%d")
print(var_date)
str(var_date)
format(var_date, "%a %C %u %w") # a:요일(축소), C:세기(+1), u:요일(1-7, 월요일부터)

# datetime
var_datetime <- as.POSIXct("2021-01-01 22:30:59", format = "%Y-%m-%d %H:%M:%S")
print(var_datetime)
str(var_datetime)
format(var_datetime, "%A %p %w") # A:요일, p:오전오후, w:요일(0-6, 일요일부터)

# typecasting & type check
var_cast_sample <- c(1:10)
var_cast_int <- as.integer(var_cast_sample)
var_cast_num <- as.numeric(var_cast_sample)
var_cast_fac <- as.factor(var_cast_sample)
var_cast_char <- as.character(var_cast_sample)
str(var_cast_int)
print(is.integer(var_cast_int))
print(is.numeric(var_cast_int))
summary(var_cast_int)
str(var_cast_num)
print(is.integer(var_cast_num)) # FALSE
print(is.numeric(var_cast_num))
summary(var_cast_num)
str(var_cast_fac)
print(is.factor(var_cast_fac))
summary(var_cast_fac)
str(var_cast_char)
print(is.character(var_cast_char))
summary(var_cast_char)

# if / for
var_iffor_base <- c(1, 2, 3, 4, 5)
if (length(var_iffor_base) <= 0) {
   print("EMPTY")
} else if (7 %in% var_iffor_base) { # %% 연산자: https://rfriend.tistory.com/35
    print("TRUE")
} else {
    print("FALSE")
}
for (item in var_iffor_base) {
    print(item)
}

# sample
## replace가 T/TRUE면 뽑은 항목이 다시 뽑힐 수 있음(복원추출)
## replace가 F/FALSE면 뽑은 항목은 다시 안 뽑음(비복원추출)
var_sample <- sample(c(1:100), 5, replace = FALSE)
print(var_sample)

# sample with fixed seed
set.seed(1320) # 실행 직후의 sample에 영향
var_sample <- sample(c(1:100), 5, replace = F)
print(var_sample)

for (i in 1:5) {
    set.seed(1320)
    var_sample <- sample(c(1:100), 5, replace = F)
    print(var_sample)
}

# function
func_square <- function(x) {
    y <- x * x
    return(y)
}
print(func_square(2))

## question
q_1 <- sample(c(1:45), 6, replace = FALSE)
print(q_1)
q_2_av <- seq(1, 99, 2) # 항목명 생략 / seq(from = 1, to = 99, by = 2)
print(q_2_av)
q_2_bv <- rep(c(1, 2, 3, 4, 5), c(2, 2, 2, 2, 2))
print(q_2_bv)
q_3 <- matrix(c(1:9), nrow = 3, byrow = TRUE)
print(q_3)
q_4 <- function(x, y) {
    return(x^2 + y + 10)
}
print(q_4(2, 4))
q_5 <- function() {
    for (i in c(2:9)) {
        for (j in c(1:9)) {
            cat(i, "*", j, "=", i * j, "\n")
        }
    }
}
q_5()
